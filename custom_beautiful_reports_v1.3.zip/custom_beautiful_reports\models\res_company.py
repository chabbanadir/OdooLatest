from odoo import fields, models

class ResCompany(models.Model):
    _inherit = "res.company"

    use_beautiful_reports = fields.Boolean(
        string="Use Beautiful Reports", 
        default=True,
        help="If checked, standard Odoo invoice and quote prints will use the Beautiful premium layout."
    )
