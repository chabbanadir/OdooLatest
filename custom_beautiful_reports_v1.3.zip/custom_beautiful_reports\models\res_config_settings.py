from odoo import fields, models

class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    use_beautiful_reports_setting = fields.Boolean(
        related="company_id.use_beautiful_reports", 
        readonly=False
    )
